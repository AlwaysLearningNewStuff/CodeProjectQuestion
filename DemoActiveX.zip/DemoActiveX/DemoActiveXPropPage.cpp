// DemoActiveXPropPage.cpp : Implementation of the CDemoActiveXPropPage property page class.

#include "pch.h"
#include "framework.h"
#include "DemoActiveX.h"
#include "DemoActiveXPropPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

IMPLEMENT_DYNCREATE(CDemoActiveXPropPage, COlePropertyPage)

// Message map

BEGIN_MESSAGE_MAP(CDemoActiveXPropPage, COlePropertyPage)
END_MESSAGE_MAP()

// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CDemoActiveXPropPage, "MFCACTIVEXCONT.DemoActiveXPropPage.1",
	0x218595d0,0xdf58,0x4e4e,0x91,0x8c,0x48,0xa8,0xca,0xc5,0xd8,0x24)

// CDemoActiveXPropPage::CDemoActiveXPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CDemoActiveXPropPage

BOOL CDemoActiveXPropPage::CDemoActiveXPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_DEMOACTIVEX_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, nullptr);
}

// CDemoActiveXPropPage::CDemoActiveXPropPage - Constructor

CDemoActiveXPropPage::CDemoActiveXPropPage() :
	COlePropertyPage(IDD, IDS_DEMOACTIVEX_PPG_CAPTION)
{
}

// CDemoActiveXPropPage::DoDataExchange - Moves data between page and properties

void CDemoActiveXPropPage::DoDataExchange(CDataExchange* pDX)
{
	DDP_PostProcessing(pDX);
}

// CDemoActiveXPropPage message handlers
