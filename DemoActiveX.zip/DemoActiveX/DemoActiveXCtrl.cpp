// DemoActiveXCtrl.cpp : Implementation of the CDemoActiveXCtrl ActiveX Control class.

#include "pch.h"
#include "framework.h"
#include "DemoActiveX.h"
#include "DemoActiveXCtrl.h"
#include "DemoActiveXPropPage.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

IMPLEMENT_DYNCREATE(CDemoActiveXCtrl, COleControl)

// Message map

BEGIN_MESSAGE_MAP(CDemoActiveXCtrl, COleControl)
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()

// Dispatch map

BEGIN_DISPATCH_MAP(CDemoActiveXCtrl, COleControl)
	DISP_FUNCTION_ID(CDemoActiveXCtrl, "Write", dispidWrite, Write, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION_ID(CDemoActiveXCtrl, "Read", dispidRead, Read, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()

// Event map

BEGIN_EVENT_MAP(CDemoActiveXCtrl, COleControl)
END_EVENT_MAP()

// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CDemoActiveXCtrl, 1)
	PROPPAGEID(CDemoActiveXPropPage::guid)
END_PROPPAGEIDS(CDemoActiveXCtrl)

// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CDemoActiveXCtrl, "MFCACTIVEXCONTRO.DemoActiveXCtrl.1",
	0x3a614790,0xdc9e,0x4e5e,0xb1,0xa3,0x91,0x97,0x84,0x57,0xc2,0x0a)

// Type library ID and version

IMPLEMENT_OLETYPELIB(CDemoActiveXCtrl, _tlid, _wVerMajor, _wVerMinor)

// Interface IDs

const IID IID_DDemoActiveX = {0x27e91eb6,0xc6b0,0x46bd,{0xa4,0x52,0x11,0x04,0x06,0x33,0x1e,0x2c}};
const IID IID_DDemoActiveXEvents = {0x7793f995,0x9e30,0x4022,{0x8b,0xfa,0x43,0x8d,0x36,0x3c,0x11,0x5b}};

// Control type information

static const DWORD _dwDemoActiveXOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CDemoActiveXCtrl, IDS_DEMOACTIVEX, _dwDemoActiveXOleMisc)

// CDemoActiveXCtrl::CDemoActiveXCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CDemoActiveXCtrl

BOOL CDemoActiveXCtrl::CDemoActiveXCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_DEMOACTIVEX,
			IDB_DEMOACTIVEX,
			afxRegApartmentThreading,
			_dwDemoActiveXOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


// CDemoActiveXCtrl::CDemoActiveXCtrl - Constructor

CDemoActiveXCtrl::CDemoActiveXCtrl()
{
	InitializeIIDs(&IID_DDemoActiveX, &IID_DDemoActiveXEvents);
	// TODO: Initialize your control's instance data here.
}

// CDemoActiveXCtrl::~CDemoActiveXCtrl - Destructor

CDemoActiveXCtrl::~CDemoActiveXCtrl()
{
	// TODO: Cleanup your control's instance data here.
}

// CDemoActiveXCtrl::OnDraw - Drawing function

void CDemoActiveXCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& /* rcInvalid */)
{
	if (!pdc)
		return;

	// TODO: Replace the following code with your own drawing code.
	pdc->FillRect(rcBounds, CBrush::FromHandle((HBRUSH)GetStockObject(WHITE_BRUSH)));
	pdc->Ellipse(rcBounds);
}

// CDemoActiveXCtrl::DoPropExchange - Persistence support

void CDemoActiveXCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	// TODO: Call PX_ functions for each persistent custom property.
}


// CDemoActiveXCtrl::OnResetState - Reset control to default state

void CDemoActiveXCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}


// CDemoActiveXCtrl message handlers


void CDemoActiveXCtrl::Write()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your dispatch handler code here
	// Code Project: this one is not visible in consumer app :(
	AfxMessageBox(_T("Success!"));
}


void CDemoActiveXCtrl::Read()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your dispatch handler code here
	// Code Project: this one is not visible in consumer app :(
	AfxMessageBox(_T("Success!"));
}
