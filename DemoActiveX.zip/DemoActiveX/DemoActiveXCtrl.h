#pragma once

// DemoActiveXCtrl.h : Declaration of the CDemoActiveXCtrl ActiveX Control class.


// CDemoActiveXCtrl : See DemoActiveXCtrl.cpp for implementation.

class CDemoActiveXCtrl : public COleControl
{
	DECLARE_DYNCREATE(CDemoActiveXCtrl)

// Constructor
public:
	CDemoActiveXCtrl();

// Overrides
public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();

// Implementation
protected:
	~CDemoActiveXCtrl();

	DECLARE_OLECREATE_EX(CDemoActiveXCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CDemoActiveXCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CDemoActiveXCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CDemoActiveXCtrl)		// Type name and misc status

// Message maps
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	DECLARE_DISPATCH_MAP()

// Event maps
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
		dispidRead = 2L,
		dispidWrite = 1L
	};
protected:
	void Write();
	void Read();
};

