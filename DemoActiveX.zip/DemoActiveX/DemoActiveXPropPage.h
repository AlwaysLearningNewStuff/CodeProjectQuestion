#pragma once

// DemoActiveXPropPage.h : Declaration of the CDemoActiveXPropPage property page class.


// CDemoActiveXPropPage : See DemoActiveXPropPage.cpp for implementation.

class CDemoActiveXPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CDemoActiveXPropPage)
	DECLARE_OLECREATE_EX(CDemoActiveXPropPage)

// Constructor
public:
	CDemoActiveXPropPage();

// Dialog Data
	enum { IDD = IDD_PROPPAGE_DEMOACTIVEX };

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	DECLARE_MESSAGE_MAP()
};

