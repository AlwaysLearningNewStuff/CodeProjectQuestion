// Machine generated IDispatch wrapper class(es) created by Microsoft Visual C++

// NOTE: Do not modify the contents of this file.  If this class is regenerated
// by Microsoft Visual C++, your modifications will be overwritten.

#include "pch.h"
#include "COCX.h"

/////////////////////////////////////////////////////////////////////////////
// COCX

IMPLEMENT_DYNCREATE(COCX, CWnd)

/////////////////////////////////////////////////////////////////////////////
// COCX Properties

/////////////////////////////////////////////////////////////////////////////
// COCX Operations
